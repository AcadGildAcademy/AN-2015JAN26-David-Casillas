package com.acadgild.creditcardhelper;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {

    EditText enterCardBalance;
    EditText yearInterestRate;
    EditText enterMinPayment;
    EditText finalCardBalance;
    EditText monthsRemaining;
    EditText interestPaid;
    Button compute;
    Button clear;
    double principle;
    double monthlyInterestPaid;
    double monthlyPrinciple;
    double monthlyBalance;
    double rate;
    double minPayment;
    int monthsRemain = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enterCardBalance = (EditText) findViewById(R.id.enterBalance);
        yearInterestRate = (EditText) findViewById(R.id.enterRate);
        enterMinPayment = (EditText) findViewById(R.id.minPayment);
        finalCardBalance = (EditText) findViewById(R.id.finalBalance);
        monthsRemaining = (EditText) findViewById(R.id.monthsRemain);
        monthsRemaining.setText(String.valueOf(monthsRemain));
        interestPaid = (EditText) findViewById(R.id.interestRate);

        compute = (Button) findViewById(R.id.compute);
        clear = (Button) findViewById(R.id.clear);

    }

    public void Compute(View v) {
        if (monthsRemain < 0) {
            Toast.makeText(getApplicationContext(),"You've paid your balance in full",Toast.LENGTH_SHORT).show();

        } else {
            monthsRemain--;
            principle = Double.valueOf(enterCardBalance.getText().toString());
            rate = Double.valueOf(yearInterestRate.getText().toString());
            minPayment = Double.valueOf(enterMinPayment.getText().toString());
            monthlyInterestPaid = Math.round((principle * (rate / (100 * 12))));
            monthlyPrinciple = minPayment - monthlyInterestPaid;
            monthlyBalance = principle - monthlyPrinciple;
            principle = monthlyBalance;
            finalCardBalance.setText(String.valueOf(monthlyBalance));
            monthsRemaining.setText(String.valueOf(monthsRemain));
            interestPaid.setText(String.valueOf(monthlyInterestPaid));
        }
    }

    public void Clear(View v) {
        enterCardBalance.setText("");
        yearInterestRate.setText("");
        enterMinPayment.setText("");
        finalCardBalance.setText("");
        monthsRemaining.setText("");
        interestPaid.setText("");
    }

}
