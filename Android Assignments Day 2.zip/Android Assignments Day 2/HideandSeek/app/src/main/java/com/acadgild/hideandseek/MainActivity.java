package com.acadgild.hideandseek;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends Activity {

    ImageView imageData;
    Button buttonHideSeek;
    int checkVisible = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageData = (ImageView) findViewById(R.id.imageView);
        buttonHideSeek = (Button) findViewById(R.id.button);
    }

    public void HideOrSeek(View v) {

        if (checkVisible == 0) {

            imageData.setVisibility(View.INVISIBLE);
            buttonHideSeek.setText("Seek");
            checkVisible = 1;
        } else {

            imageData.setVisibility(View.VISIBLE);
            buttonHideSeek.setText("Hide");
            checkVisible = 0;
        }

    }

}
