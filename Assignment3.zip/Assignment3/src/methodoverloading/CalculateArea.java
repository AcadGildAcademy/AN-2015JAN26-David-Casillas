package methodoverloading;

public class CalculateArea {
	
	public int length;
	public int width;
	public int area;
	
	public CalculateArea() {
		
		this.length = 0;
		this.width = 0;
		area = 0;
		
	}
	
	public CalculateArea(int length) {
		
		this.length = length;
		area = getArea(length);
		
	}
	
	public CalculateArea(int length, int width) {
		
		this.length = length;
		this.width = width;
		area = getArea(length,width);
	}
	
	private int getArea(int a, int b) {
		return a*b;
	}
	
	private int getArea(int a) {
		return a*a;
	}
	
	
	
	
}
