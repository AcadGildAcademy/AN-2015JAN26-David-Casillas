package methodoverriding;

public class InterestRates {

	public static void main(String[] args) {
		
		SBIbank sbi = new SBIbank();
		ICICIbank icici = new ICICIbank();
		AXISbank axis = new AXISbank();
		
		System.out.println("SBI Bank has an interest rate of " + sbi.getRateOfInterest());
		System.out.println("ICICI Bank has an interest rate of " + icici.getRateOfInterest());
		System.out.println("AXIS Bank has an interest rate of " + axis.getRateOfInterest());

	}

}
