package methodoverriding;

public class Bank {
	
	public String rate = "n%";
	
	public String getRateOfInterest() {
	
		return rate;
	}

}
