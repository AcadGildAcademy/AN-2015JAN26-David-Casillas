package abstractexercise;

public class PlayInstrument {

	public static void main(String[] args) {
		
		ElectricGuitar ec = new ElectricGuitar();
		ElectricBassGuitar ebc = new ElectricBassGuitar();
		
		ec.playInstrument();
		ebc.playInstrument();	

	}

}
