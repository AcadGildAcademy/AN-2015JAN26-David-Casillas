package abstractexercise;

public class ElectricBassGuitar extends StringedInstrument {
	
	public ElectricBassGuitar() {
		sound = "electric bass guitar sound";
		stringNum = 4;
	}
	
	@Override
	void playInstrument() {
		
		System.out.println(sound);
		
	}
	
	@Override
	int numberOfStrings() {
		
		return stringNum;
	}


}
