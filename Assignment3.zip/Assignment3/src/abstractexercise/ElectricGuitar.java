package abstractexercise;

class ElectricGuitar extends StringedInstrument {
	
	public ElectricGuitar() {
		sound = "electric guitar sound";
		stringNum = 5;
	}
	
	@Override
	void playInstrument() {
		
		System.out.println(sound);
		
	}
	
	@Override
	int numberOfStrings() {
		
		return stringNum;
	}

}
