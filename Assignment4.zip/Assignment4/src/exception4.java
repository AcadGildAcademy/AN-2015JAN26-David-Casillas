
public class exception4 {

	public static void main(String[] args) {
		
		Integer integer = null;		
		
		try {
			
			int n = integer.intValue();			
			System.out.println(n);
			
			}
			catch (NullPointerException e) {
				System.out.println("Object is set to null. " + e);
			}

	}

}
