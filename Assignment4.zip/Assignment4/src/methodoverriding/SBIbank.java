package methodoverriding;

public class SBIbank extends Bank{
	
	@Override
	public String getRateOfInterest() {
		
		return "8%";		
	} 

}
