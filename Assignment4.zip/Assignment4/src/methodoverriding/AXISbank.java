package methodoverriding;

public class AXISbank extends Bank{
	
	@Override
	public String getRateOfInterest() {
		
		return "9%";		
	} 
}
