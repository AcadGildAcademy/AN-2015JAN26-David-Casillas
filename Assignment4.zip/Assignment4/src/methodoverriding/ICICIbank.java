package methodoverriding;

public class ICICIbank extends Bank{
	
	@Override
	public String getRateOfInterest() {
		
		return "7%";		
	} 
}
