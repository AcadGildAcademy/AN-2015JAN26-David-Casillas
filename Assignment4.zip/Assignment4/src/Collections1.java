import java.util.ArrayList;
import java.util.Iterator;


public class Collections1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> num = new ArrayList<Integer>();
		
		num.add(0);
		num.add(1);
		num.add(2);
		num.add(3);
		num.add(4);
		
		Iterator<Integer> i = num.iterator();
		
		while(i.hasNext()) {
			
			int element = i.next();
			System.out.println(element);
		}		
	}
}
