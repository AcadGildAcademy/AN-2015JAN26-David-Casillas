import java.util.HashSet;
import java.util.Iterator;




public class Collections2 {

	public static void main(String[] args) {
		
		HashSet<String> set = new HashSet<String>();
		
		set.add("Acad");
		set.add("Gild");
		set.add("is fun");
		
		Iterator<String> itr = set.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
			
	}

}

