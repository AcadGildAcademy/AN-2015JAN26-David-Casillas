import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class Collections3 {

	public static void main(String[] args) {

		Map<Integer, String> set = new HashMap<Integer, String>();

		set.put(1, "tutorials");
		set.put(2, "point"); 
		set.put(3, "is best");

		Set<Entry<Integer, String>> entry = set.entrySet();
		Iterator<Entry<Integer, String>> itr = entry.iterator();

		while(itr.hasNext()) {

			Map.Entry<Integer, String> entries = (Map.Entry<Integer, String>) itr.next();

			Integer key = entries.getKey();
			String value = entries.getValue();

			System.out.println(key + "=" + value);

		}

	}
}
