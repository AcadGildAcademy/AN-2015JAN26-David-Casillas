package abstractexercise;

class StringedInstrument extends Instrument {
	
	int stringNum;

	@Override
	void playInstrument() {
		// TODO Auto-generated method stub
		
	}
	
	int numberOfStrings() {
		
		return stringNum;
	}

}
