package abstractexercise;

abstract class Instrument {
	
	String sound;
	
	abstract void playInstrument();

}
