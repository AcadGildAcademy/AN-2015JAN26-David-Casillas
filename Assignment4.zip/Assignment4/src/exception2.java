
public class exception2 {

	public static void main(String[] args) {

				
		try {
			
		int num = Integer.parseInt("XYZ");		
		System.out.println(num);
		
		}
		catch (NumberFormatException e) {
			System.out.println("XYZ cannot be parsed to int. " + e);
		}
		
	}

}
