package threads;

public class PriorityThread implements Runnable {
	
	public PriorityThread() {
		
	}

	public void run() {

		System.out.println(Thread.currentThread());
		
	}

}
