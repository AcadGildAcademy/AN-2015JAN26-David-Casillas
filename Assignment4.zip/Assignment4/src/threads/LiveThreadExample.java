package threads;

public class LiveThreadExample {

	public static void main(String[] args) {

		LiveThread lt = new LiveThread();
		
		lt.start();
		
		while (lt.isAlive()) {
			System.out.println("Main thread will be alive till the child thread is live");
		}

	}

}
