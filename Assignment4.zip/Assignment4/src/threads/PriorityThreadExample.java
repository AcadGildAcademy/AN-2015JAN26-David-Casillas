package threads;

public class PriorityThreadExample {

	public static void main(String[] args) {

		Thread minimum = new Thread(new PriorityThread(), "Thread A");
		Thread normal = new Thread(new PriorityThread(), "Thread B");
		Thread maximum = new Thread(new PriorityThread(), "Thread C");
		
		minimum.setPriority(Thread.MIN_PRIORITY);
		normal.setPriority(Thread.NORM_PRIORITY);
		maximum.setPriority(Thread.MAX_PRIORITY);
		
		minimum.start();
		normal.start();
		maximum.start();		
		
		try {
			
			Thread.currentThread();
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			System.out.println(Thread.currentThread());
		}

	}

}
