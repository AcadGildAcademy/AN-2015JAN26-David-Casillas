package threads;

public class LiveThread extends Thread {

	@Override
	public void run() {

		for (int i=0; i<=10; i++) {
			
			System.out.println("Printing the count " + i);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Thread has been interrupted " + e);
			}
		}
	}

}
