
public class exception3 {

	public static void main(String[] args) {
		
		String name = "ACAD Gild";

		try {
					
			char ch = name.charAt(9);
			System.out.println(ch);
			
			}
			catch (StringIndexOutOfBoundsException e) {
				System.out.println("The string " + name + " has only 9 characters. " + e);
			}
			
	}

}
