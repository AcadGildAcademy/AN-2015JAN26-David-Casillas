

public class exception1 {

	public static void main(String[] args) {

		int array[] = {0,1,2,3,4};
		
		try {
		
		System.out.println(array[6]);
		}
		
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("There are only 5 elements in the array. " + e);
		}
		

	}

}
