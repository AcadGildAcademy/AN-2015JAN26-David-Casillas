package methodoverloading;

public class RectangleArea {

	public static void main(String[] args) {

		CalculateArea shape = new CalculateArea();
		System.out.println(shape.area);
		
		CalculateArea square = new CalculateArea(3);
		System.out.println(square.area);
		
		CalculateArea rectangle = new CalculateArea(3,5);
		System.out.println(rectangle.area);

	}

}
