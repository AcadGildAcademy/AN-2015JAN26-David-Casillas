package inheritance;

public class CalculateAreaOfShapes {

	public static void main(String[] args) {
		
		Rectangle rect = new Rectangle(8,9);
		Triangle tri = new Triangle(7,5);
		
		System.out.println("The area of a rectangle with base " + rect.base + " and height " + rect.height + " is " + rect.area);
		System.out.println("The area of a triangle with base " + tri.base + " and height " + tri.height + " is " + tri.area);

	}

}
