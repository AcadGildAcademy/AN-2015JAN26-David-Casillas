package inheritance;

public class Triangle extends Rectangle {

	Triangle(int base, int height) {
		super(base, height);
		
	}
	
	@Override
	public double getArea(int a, int b) {
		return a*b*.5;
	}

}
