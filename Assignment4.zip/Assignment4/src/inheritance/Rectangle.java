package inheritance;

public class Rectangle {
	
	int base;
	int height;
	double area;
	
	Rectangle(int base, int height) {
		
		this.base = base;
		this.height = height;
		area = getArea(base, height);

	}

	public double getArea(int a, int b) {
		
		return a*b;
	}
}
