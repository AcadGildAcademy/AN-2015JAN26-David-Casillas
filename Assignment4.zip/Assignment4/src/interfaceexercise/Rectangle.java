package interfaceexercise;

public class Rectangle implements Shape {

	public void draw() {
		// TODO Auto-generated method stub
		
	}

	public void getArea() {
		// TODO Auto-generated method stub
		
	}

}
